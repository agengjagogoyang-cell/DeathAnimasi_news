package id.zentra.deathdimension;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketContainer;
import org.bukkit.entity.Player;

/** Dipisah supaya class ini hanya dimuat kalau ProtocolLib ada. */
final class CameraBridge {
    private CameraBridge() {}

    /** Arahkan kamera klien ke entity tertentu. Kirim entityId pemain sendiri untuk reset. */
    static void set(Player p, int entityId) {
        ProtocolManager pm = ProtocolLibrary.getProtocolManager();
        PacketContainer c = pm.createPacket(PacketType.Play.Server.CAMERA);
        c.getIntegers().write(0, entityId);
        pm.sendServerPacket(p, c);
    }
}
