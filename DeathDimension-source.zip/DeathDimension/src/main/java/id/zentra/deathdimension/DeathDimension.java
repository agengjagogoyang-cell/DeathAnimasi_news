package id.zentra.deathdimension;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

public final class DeathDimension extends JavaPlugin implements Listener, CommandExecutor {

    private static final int CY = 100; // tinggi lantai arena

    private World world;
    private boolean protocolLib;
    private File dataFile;
    private YamlConfiguration data;

    private final Map<UUID, Session> sessions = new HashMap<>();
    private final Map<UUID, Location> lastSafe = new HashMap<>();

    static final class Session {
        final UUID id;
        final Location ret;
        final int slot;
        final int total;
        ArmorStand seat;
        ArmorStand cam;
        ItemDisplay sword;
        BukkitTask task;
        int t;

        Session(UUID id, Location ret, int slot, int total) {
            this.id = id;
            this.ret = ret;
            this.slot = slot;
            this.total = total;
        }
    }

    /** Generator void total. */
    static final class VoidGen extends ChunkGenerator {
        @Override
        public Location getFixedSpawnLocation(World w, Random r) {
            return new Location(w, 0.5, CY + 1, 0.5);
        }
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);

        protocolLib = Bukkit.getPluginManager().isPluginEnabled("ProtocolLib");
        if (!protocolLib) {
            getLogger().warning("ProtocolLib tidak ditemukan -> kamera third person TIDAK aktif. Pasang ProtocolLib.");
        }

        loadWorld();
        Bukkit.getPluginManager().registerEvents(this, this);
        if (getCommand("deathdim") != null) getCommand("deathdim").setExecutor(this);

        // jaga world tetap malam & cerah
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (world != null) {
                world.setTime(18000);
                world.setStorm(false);
            }
        }, 20L, 100L);
    }

    @Override
    public void onDisable() {
        for (Session s : new HashMap<>(sessions).values()) finish(s, false);
    }

    private void loadWorld() {
        String name = getConfig().getString("world-name", "zentra_death");
        world = Bukkit.getWorld(name);
        if (world == null) {
            world = new WorldCreator(name)
                    .environment(World.Environment.NORMAL)
                    .generator(new VoidGen())
                    .generateStructures(false)
                    .createWorld();
        }
        if (world == null) {
            getLogger().severe("Gagal membuat world " + name);
            return;
        }
        world.setSpawnLocation(0, CY + 1, 0);
        for (int cx = -3; cx <= 3; cx++)
            for (int cz = -3; cz <= 3; cz++)
                world.getChunkAt(cx, cz).setForceLoaded(true);

        if (world.getBlockAt(0, CY, 0).getType() == Material.AIR) buildArena(world);
    }

    // ------------------------------------------------------------------ arena

    private static void set(World w, int x, int y, int z, Material m) {
        w.getBlockAt(x, y, z).setType(m, false);
    }

    private void buildArena(World w) {
        Random rnd = new Random(7);
        final int R = 13;

        // platform utama (pulau terbalik melayang)
        for (int x = -R; x <= R; x++) {
            for (int z = -R; z <= R; z++) {
                double d = Math.sqrt(x * x + z * z);
                if (d > R) continue;
                Material top;
                if (d <= 2.5) top = Material.CHISELED_POLISHED_BLACKSTONE;
                else if (d >= R - 1.5) top = Material.CRYING_OBSIDIAN;
                else top = (Math.round(d) % 3 == 0) ? Material.POLISHED_BLACKSTONE : Material.POLISHED_BLACKSTONE_BRICKS;
                set(w, x, CY, z, top);

                int depth = (int) ((R - d) * 0.8);
                for (int i = 1; i <= depth; i++) {
                    Material m = (i > 3 && rnd.nextInt(5) == 0) ? Material.SCULK : Material.DEEPSLATE_BRICKS;
                    set(w, x, CY - i, z, m);
                }
            }
        }

        // 8 tiang lentera di pinggir
        for (int k = 0; k < 8; k++) {
            double a = Math.toRadians(k * 45.0 + 22.5);
            int px = (int) Math.round(Math.cos(a) * (R - 2));
            int pz = (int) Math.round(Math.sin(a) * (R - 2));
            for (int h = 1; h <= 3; h++) set(w, px, CY + h, pz, Material.BLACKSTONE_WALL);
            set(w, px, CY + 4, pz, Material.SOUL_LANTERN);
        }

        // altar tengah: api jiwa
        set(w, 0, CY + 1, 0, Material.SOUL_SOIL);
        set(w, 0, CY + 2, 0, Material.SOUL_FIRE);

        // dasar 8 slot korban
        for (int s = 0; s < 8; s++) {
            double a = Math.toRadians(s * 45.0);
            int bx = (int) Math.round(Math.cos(a) * 6);
            int bz = (int) Math.round(Math.sin(a) * 6);
            set(w, bx, CY, bz, Material.OBSIDIAN);
        }

        // pulau-pulau kecil melayang
        for (int i = 0; i < 8; i++) {
            double a = Math.toRadians(i * 45.0 + 22);
            double rad = 24 + rnd.nextInt(10);
            int ix = (int) (Math.cos(a) * rad);
            int iz = (int) (Math.sin(a) * rad);
            int iy = CY - 4 + rnd.nextInt(18);
            int r = 3 + rnd.nextInt(2);
            for (int x = -r; x <= r; x++) {
                for (int z = -r; z <= r; z++) {
                    double d = Math.sqrt(x * x + z * z);
                    if (d > r) continue;
                    set(w, ix + x, iy, iz + z, Material.DEEPSLATE_TILES);
                    int depth = (int) ((r - d) * 1.2) + 1;
                    for (int k = 1; k <= depth; k++)
                        set(w, ix + x, iy - k, iz + z, (k > 2 && rnd.nextInt(3) == 0) ? Material.SCULK : Material.DEEPSLATE_BRICKS);
                }
            }
            int h = 3 + rnd.nextInt(4);
            for (int k = 1; k < h; k++) set(w, ix, iy + k, iz, Material.BLACKSTONE_WALL);
            set(w, ix, iy + h, iz, Material.SOUL_LANTERN);
        }

        // cincin halo cahaya di langit
        for (int i = 0; i < 72; i++) {
            double a = Math.toRadians(i * 5.0);
            set(w, (int) Math.round(Math.cos(a) * 38), CY + 28, (int) Math.round(Math.sin(a) * 38), Material.END_ROD);
        }
    }

    // ------------------------------------------------------------------ util

    private static Component c(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s);
    }

    private static double ease(double x) {
        x = Math.max(0, Math.min(1, x));
        return 1 - Math.pow(1 - x, 3);
    }

    private boolean inDeathWorld(Player p) {
        return world != null && p.getWorld().equals(world);
    }

    private boolean locked(Entity e) {
        return e instanceof Player p && sessions.containsKey(p.getUniqueId());
    }

    private Location respawnOf(Player p) {
        Location l = p.getRespawnLocation();
        if (l == null) l = Bukkit.getWorlds().get(0).getSpawnLocation();
        return l;
    }

    private void saveData() {
        try {
            data.save(dataFile);
        } catch (IOException ex) {
            getLogger().warning("Gagal simpan data.yml: " + ex.getMessage());
        }
    }

    private void camera(Player p, int entityId) {
        if (!protocolLib) return;
        try {
            CameraBridge.set(p, entityId);
        } catch (Throwable ex) {
            getLogger().warning("Gagal set kamera: " + ex.getMessage());
        }
    }

    private int freeSlot() {
        boolean[] used = new boolean[8];
        for (Session s : sessions.values()) used[s.slot % 8] = true;
        for (int i = 0; i < 8; i++) if (!used[i]) return i;
        return sessions.size() % 8;
    }

    // ------------------------------------------------------------------ masuk

    public boolean enter(Player p, Location ret) {
        if (world == null || sessions.containsKey(p.getUniqueId())) return false;

        int slot = freeSlot();
        double ang = Math.toRadians(slot * 45.0);
        Vector out = new Vector(Math.cos(ang), 0, Math.sin(ang));
        Location base = new Location(world, 0.5 + out.getX() * 6, CY + 1, 0.5 + out.getZ() * 6);
        Location seatLoc = base.clone().add(0, getConfig().getDouble("hang-height", 1.2), 0);
        seatLoc.setDirection(out);

        int total = Math.max(5, getConfig().getInt("duration-seconds", 15)) * 20;
        Session s = new Session(p.getUniqueId(), ret, slot, total);

        data.set("pending." + p.getUniqueId(), ret);
        saveData();

        if (p.isInsideVehicle()) p.leaveVehicle();
        p.setFallDistance(0);
        p.setVelocity(new Vector(0, 0, 0));
        p.setFireTicks(0);
        p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 30, 0, false, false, false));
        p.teleport(seatLoc);

        s.seat = world.spawn(seatLoc, ArmorStand.class, a -> {
            a.setInvisible(true);
            a.setMarker(true);
            a.setGravity(false);
            a.setSilent(true);
            a.setInvulnerable(true);
            a.setBasePlate(false);
            a.setPersistent(false);
        });
        s.cam = world.spawn(seatLoc, ArmorStand.class, a -> {
            a.setInvisible(true);
            a.setMarker(true);
            a.setGravity(false);
            a.setSilent(true);
            a.setInvulnerable(true);
            a.setBasePlate(false);
            a.setPersistent(false);
        });

        float scale = (float) getConfig().getDouble("sword.scale", 5.0);
        float roll = (float) Math.toRadians(getConfig().getDouble("sword.roll-degrees", -135));
        Location swordLoc = seatLoc.clone().add(0, 0.9, 0);
        s.sword = world.spawn(swordLoc, ItemDisplay.class, d -> {
            d.setItemStack(new ItemStack(Material.NETHERITE_SWORD));
            d.setBillboard(Display.Billboard.VERTICAL);
            d.setBrightness(new Display.Brightness(15, 15));
            d.setTransformation(new Transformation(
                    new Vector3f(0, 0, 0),
                    new AxisAngle4f(roll, 0, 0, 1),
                    new Vector3f(scale, scale, scale),
                    new AxisAngle4f(0, 0, 0, 1)));
            d.setPersistent(false);
        });

        sessions.put(p.getUniqueId(), s);

        p.showTitle(Title.title(
                c("&4&lDEATH DIMENSION"),
                c("&7Kamu tertusuk di antara dua dunia..."),
                Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(3), Duration.ofMillis(800))));
        p.playSound(p.getLocation(), Sound.ENTITY_ELDER_GUARDIAN_CURSE, 1f, 0.6f);

        // duduk di kursi tak terlihat + kamera, sedikit tertunda supaya teleport selesai
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (sessions.get(s.id) != s || !p.isOnline()) return;
            s.seat.addPassenger(p);
            camera(p, s.cam.getEntityId());
        }, 3L);

        s.task = Bukkit.getScheduler().runTaskTimer(this, () -> tick(s), 4L, 1L);
        return true;
    }

    // ------------------------------------------------------------------ tick

    private void tick(Session s) {
        Player p = Bukkit.getPlayer(s.id);
        if (p == null || !p.isOnline()) {
            finish(s, false);
            return;
        }
        s.t++;

        // pastikan tetap duduk
        if (p.getVehicle() != s.seat) {
            if (p.getLocation().distanceSquared(s.seat.getLocation()) > 2.25) p.teleport(s.seat.getLocation());
            s.seat.addPassenger(p);
        }
        p.setFallDistance(0);

        // kamera: menjauh di awal (FOV menjauh), mendekat lagi di akhir
        double min = getConfig().getDouble("camera.min-distance", 2.5);
        double max = getConfig().getDouble("camera.max-distance", 9.0);
        int zin = Math.max(1, getConfig().getInt("camera.zoom-in-ticks", 80));
        int zout = Math.max(1, getConfig().getInt("camera.zoom-out-ticks", 40));
        double dist;
        if (s.t < zin) dist = min + (max - min) * ease(s.t / (double) zin);
        else if (s.t > s.total - zout) dist = min + (max - min) * ease((s.total - s.t) / (double) zout);
        else dist = max;

        // kamera mengorbit di depan wajah pemain, ikut arah putar layar
        Location body = p.getLocation().add(0, 0.9, 0);
        Vector look = p.getLocation().getDirection();
        Location camLoc = body.clone().add(look.clone().multiply(dist));
        camLoc.setDirection(body.toVector().subtract(camLoc.toVector()));
        s.cam.teleport(camLoc);

        // efek
        World w = s.seat.getWorld();
        double a = s.t * 0.35;
        for (int i = 0; i < 2; i++) {
            double aa = a + i * Math.PI;
            Location pl = body.clone().add(Math.cos(aa) * 1.3, Math.sin(s.t * 0.1 + i) * 0.8, Math.sin(aa) * 1.3);
            w.spawnParticle(Particle.SOUL_FIRE_FLAME, pl, 1, 0, 0, 0, 0);
        }
        if (s.t % 3 == 0)
            w.spawnParticle(Particle.DUST, body, 4, 0.4, 0.7, 0.4, 0, new Particle.DustOptions(Color.fromRGB(150, 0, 20), 1.3f));
        if (s.t % 5 == 0) w.spawnParticle(Particle.SCULK_SOUL, body, 2, 0.5, 0.8, 0.5, 0.02);
        if (s.t % 8 == 0) w.spawnParticle(Particle.REVERSE_PORTAL, body, 12, 0.8, 1, 0.8, 0.1);
        if (s.t % 10 == 0 && s.slot == 0) {
            for (int i = 0; i < 30; i++) w.spawnParticle(Particle.END_ROD, 0.5, CY + 3 + i, 0.5, 1, 0, 0, 0, 0);
        }
        if (s.t % 40 == 0) p.playSound(p.getLocation(), Sound.ENTITY_WARDEN_HEARTBEAT, 1f, 1f);
        if (s.t % 120 == 1) p.playSound(p.getLocation(), Sound.AMBIENT_SOUL_SAND_VALLEY_MOOD, 1f, 1f);

        if (s.t % 20 == 0) {
            int left = Math.max(0, (s.total - s.t) / 20);
            p.sendActionBar(c("&4☠ &7Kembali dalam &f" + left + "s"));
        }

        if (s.t == s.total - 15)
            p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 25, 0, false, false, false));
        if (s.t >= s.total) finish(s, true);
    }

    // ------------------------------------------------------------------ keluar

    private void finish(Session s, boolean notify) {
        if (!sessions.remove(s.id, s)) return;
        if (s.task != null) s.task.cancel();

        Player p = Bukkit.getPlayer(s.id);
        if (p != null) {
            camera(p, p.getEntityId()); // reset kamera ke diri sendiri
            if (p.isInsideVehicle()) p.leaveVehicle();
        }
        if (s.cam != null) s.cam.remove();
        if (s.seat != null) s.seat.remove();
        if (s.sword != null) s.sword.remove();

        if (p != null) {
            p.removePotionEffect(PotionEffectType.BLINDNESS);

            Location ret = s.ret;
            if (ret == null || ret.getWorld() == null) ret = respawnOf(p);
            p.teleport(ret);
            p.setFallDistance(0);
            p.setVelocity(new Vector(0, 0, 0));

            double maxHp = p.getAttribute(Attribute.MAX_HEALTH).getValue();
            double pct = getConfig().getDouble("return-health-percent", 50) / 100.0;
            p.setHealth(Math.max(1.0, Math.min(maxHp, maxHp * pct)));
            if (p.getFoodLevel() < 10) p.setFoodLevel(10);

            if (notify) {
                p.showTitle(Title.title(
                        c("&a&lKEMBALI"),
                        c("&7Kamu kembali ke dunia yang hidup"),
                        Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(2), Duration.ofMillis(600))));
                p.playSound(p.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1f, 1.2f);
            }
        }
        data.set("pending." + s.id, null);
        saveData();
    }

    // ------------------------------------------------------------------ pemicu

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (inDeathWorld(p) || sessions.containsKey(p.getUniqueId())) {
            e.setCancelled(true);
            return;
        }
        if (world == null || p.hasPermission("deathdim.bypass")) return;
        if (p.getHealth() - e.getFinalDamage() > 0) return;
        if (getConfig().getBoolean("only-void", false) && e.getCause() != EntityDamageEvent.DamageCause.VOID) return;
        if (p.getInventory().getItemInMainHand().getType() == Material.TOTEM_OF_UNDYING
                || p.getInventory().getItemInOffHand().getType() == Material.TOTEM_OF_UNDYING) return;

        e.setCancelled(true);

        Location ret;
        if ("death".equalsIgnoreCase(getConfig().getString("return-to", "respawn"))) {
            if (e.getCause() == EntityDamageEvent.DamageCause.VOID) {
                ret = lastSafe.get(p.getUniqueId());
                if (ret == null) ret = respawnOf(p);
            } else {
                ret = p.getLocation();
            }
        } else {
            ret = respawnOf(p);
        }
        enter(p, ret.clone());
    }

    // ------------------------------------------------------------------ kunci pemain

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        Location f = e.getFrom();
        Location t = e.getTo();
        if (t == null) return;

        if (sessions.containsKey(p.getUniqueId())) {
            if (f.getX() != t.getX() || f.getY() != t.getY() || f.getZ() != t.getZ()) {
                e.setTo(new Location(f.getWorld(), f.getX(), f.getY(), f.getZ(), t.getYaw(), t.getPitch()));
            }
            return;
        }
        if (!inDeathWorld(p) && p.isOnGround()
                && (f.getBlockX() != t.getBlockX() || f.getBlockZ() != t.getBlockZ())
                && t.getY() > t.getWorld().getMinHeight() + 5) {
            lastSafe.put(p.getUniqueId(), t.clone());
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (locked(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (locked(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (locked(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (locked(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (locked(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onSwap(PlayerSwapHandItemsEvent e) {
        if (locked(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (locked(e.getEntity())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onInvOpen(InventoryOpenEvent e) {
        if (locked(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onInvClick(InventoryClickEvent e) {
        if (locked(e.getWhoClicked())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onFood(FoodLevelChangeEvent e) {
        if (locked(e.getEntity())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent e) {
        if (world != null && e.getLocation().getWorld().equals(world)
                && e.getSpawnReason() != CreatureSpawnEvent.SpawnReason.CUSTOM) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (!locked(p) || p.hasPermission("deathdim.admin")) return;
        String cmd = e.getMessage().substring(1).split(" ")[0].toLowerCase();
        if (getConfig().getStringList("allowed-commands").contains(cmd)) return;
        e.setCancelled(true);
        p.sendMessage(c("&cKamu tidak bisa memakai command saat di Death Dimension."));
    }

    // ------------------------------------------------------------------ keluar / masuk server

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Session s = sessions.get(e.getPlayer().getUniqueId());
        if (s != null) finish(s, false);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!p.isOnline() || sessions.containsKey(p.getUniqueId())) return;
            String key = "pending." + p.getUniqueId();
            if (inDeathWorld(p) || data.contains(key)) {
                Location l = data.getLocation(key);
                if (l == null || l.getWorld() == null) l = respawnOf(p);
                if (inDeathWorld(p)) {
                    if (p.isInsideVehicle()) p.leaveVehicle();
                    camera(p, p.getEntityId());
                    p.removePotionEffect(PotionEffectType.BLINDNESS);
                    p.teleport(l);
                }
                data.set(key, null);
                saveData();
            }
        }, 5L);
    }

    // ------------------------------------------------------------------ command admin

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(c("&e/deathdim <send|release|reload> [pemain]"));
            return true;
        }
        String sub = args[0].toLowerCase();
        if (sub.equals("reload")) {
            reloadConfig();
            sender.sendMessage(c("&aConfig dimuat ulang."));
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(c("&cSebutkan nama pemain."));
            return true;
        }
        Player t = Bukkit.getPlayerExact(args[1]);
        if (t == null) {
            sender.sendMessage(c("&cPemain tidak ditemukan."));
            return true;
        }
        if (sub.equals("send")) {
            boolean ok = enter(t, t.getLocation().clone());
            sender.sendMessage(c(ok ? "&a" + t.getName() + " dikirim ke Death Dimension." : "&cGagal / sudah di sana."));
        } else if (sub.equals("release")) {
            Session s = sessions.get(t.getUniqueId());
            if (s == null) sender.sendMessage(c("&cPemain tidak sedang di Death Dimension."));
            else {
                finish(s, true);
                sender.sendMessage(c("&a" + t.getName() + " dikembalikan."));
            }
        }
        return true;
    }
}
